using System.IO;
using UnityEngine;

public class diSyData
{
    public string dialogueBoxPath;

    public static GameObject LoadPrefab(string path_resources,string name, string parent_)//In resources
    {
        GameObject obj = Object.Instantiate(Resources.Load(path_resources) as GameObject);
        GameObject parent = GameObject.Find(parent_);
        obj.transform.SetParent(parent.transform, false);
        obj.name = name;
        return obj;
    }
    public static GameObject LoadPrefab(string path_resources, string name)//In resources
    {
        GameObject obj = Object.Instantiate(Resources.Load(path_resources) as GameObject);
        obj.name = name;
        return obj;
    }
    public static void WriteJson<T>(T data, string path)
    {
        string json = JsonUtility.ToJson(data, true);

        using (StreamWriter sw = new(Application.dataPath + "/" + path))
        {
            Debug.Log("[WriteJson] write json, to: " + path);
            sw.WriteLine(json);
            sw.Close();
        }
    }
    public static T ReadJson<T>(T data, string path)
    {
        string json;

        using (StreamReader sr = new(Application.dataPath+"/" + path))
        {
            Debug.Log("[ReadJson] read json, to: " + path);
            json = sr.ReadToEnd();
            sr.Close();
        }
        return data = JsonUtility.FromJson<T>(json);
    }
    public void SetToDefault()
    {
        dialogueBoxPath = "DiSy/UI/DialogueBox";
    }
}