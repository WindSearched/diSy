using System.Collections;
using System.IO;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem.Interactions;

public class ReaderSc : MonoBehaviour
{
    public string ReadFile;
    public string DialogueBoxName;
    public string BoxPath_inResource;

    public diSyData data;
    public DsAc ac;
    public Parsed p;
    private GameObject box;
    private TextMeshProUGUI speaker;
    private TextMeshProUGUI dialogue;


    private bool ifNextDialogue = false;
    private void Awake()
    {
        ac = new DsAc();

        ac.NextDialogue.next.performed +=
            cxt =>
            {
                if (cxt.interaction is TapInteraction)
                {
                    ifNextDialogue = true;
                }
            };
    }
    private void OnEnable()
    {
        ac.Enable();
    }
    private void OnDisable()
    {
        ac.Disable();
    }

    void Start()
    {
        p = new Parsed();
        //data = diSyData.ReadJson(data, "DiSy/data.json");

        StartCoroutine(Load(Application.dataPath + "/" + ReadFile));
    }
    //
    // next is nucleus of script
    //
    private string[] funcNames ={
            "play",
            "stop",
            "create"
        };
    public IEnumerator Load(string filePath)
    {
        bool isFirstTime = true;

        box = diSyData.LoadPrefab(BoxPath_inResource,DialogueBoxName,"Canvas");
        speaker = box.transform.Find("speaker").gameObject.GetComponent<TextMeshProUGUI>();
        dialogue = box.transform.Find("dialogue").gameObject.GetComponent<TextMeshProUGUI>();

        foreach (string line in File.ReadLines(filePath))//for find the dialogue part on file .diSy
        {
            if (line[0] == '[')//check if line has some func to execute
            {
                FuncParse(line);
            }
            else
            {
                NormalParse(line, 0);
            }

            yield return null;
            while (true)//wait for clic
            {
                if (isFirstTime)
                {
                    isFirstTime = false;
                    break;
                }
                yield return null;
                if (ifNextDialogue)
                    break;
            }
            Dialoging();
            ifNextDialogue = false;
        }
        while (true)//wait for clic
        {
            if (isFirstTime)
            {
                isFirstTime = false;
                break;
            }
            yield return null;
            if (ifNextDialogue)
                break;
        }
        Destroy(box);
    }
    public void NormalParse(string parse, int initPos, char cut = ':')//cut string in two
    {
        for (int i = initPos; i < parse.Length; i++)
        {
            char c = parse[i];
            if (c == ')')
            {
                p.finished = true;

            }

            if (c == cut || p.finished)
            {
                p.cutPos = i + 1;

                char[] cache = new char[i];//1st part
                for (int j = initPos; j < i; j++)
                {
                    cache[j - initPos] = parse[j];
                }
                p.first = new string(cache).TrimEnd('\0');

                cache = new char[parse.Length - i];//2nd part
                for (int j = i + 1; j < parse.Length; j++)
                {
                    cache[j - (i + 1)] = parse[j];
                }
                p.second = new string(cache).TrimEnd('\0');

                return;
            }
        }
        Debug.LogError("Do not find cut \'" + cut + "\'");
    }
    public void FuncParse(string line)
    {
        int v = 0;
        Debug.Log("[func parse] func:" + v++);

        NormalParse(line, 1, '(');//get function name

        int fIndx;
        for (fIndx = 0; fIndx < funcNames.Length; fIndx++)//get func index
        {
            if (p.first == funcNames[fIndx])
            {
                break;
            }
            if (fIndx >= funcNames.Length)
            {
                Debug.LogError("Do not find function \"" + p.first + "\"");
                return;
            }
        }


        string[] val = new string[10];
        int i = 0;
        while (true)//for find value
        {
            NormalParse(p.second, 0, ',');//get value
            val[i] = p.first;
            if (p.finished)
            {
                p.finished = false;
                break;
            }
            i++;
        }

        Functions(fIndx, val);
        NormalParse(p.second, 0);//get dialogue
    }
    public static void Functions(int funcIndx, string[] val)//to use functions in file .DiSy
    {
        switch (funcIndx)
        {
            case 0:
                play(val[0], val[1], val[2]);
                break;
            case 1:
                stop(val[0], val[1]);
                break;
            case 2:
                create(val[0], int.Parse(val[1]), int.Parse(val[2]), int.Parse(val[3]), val[4]);
                break;
            default:
                Debug.LogError("Do not find function index " + funcIndx);
                break;
        }
    }
    public void Dialoging()
    {
        Debug.Log("[Dialoging] " + p.first + ":" + p.second);

        speaker.text = p.first;
        dialogue.text = p.second;
    }
    //
    //Under is .Disy function
    //
    private static void play(string path, string name, string gamePath)//to play music
    {
        Debug.Log("Play func/" + path + "," + name + "," + gamePath);
    }
    private static void stop(string name, string gamePath)//to stop music
    {
        Debug.Log("Stop func/" + name + "," + gamePath);
    }
    private static void create(string path, int x, int y, int z, string gamePath)//to create some object in game
    {
        Debug.Log("Create func/" + path + "," + x + "," + y + "," + z + "," + gamePath);
    }
}

public class Parsed
{
    public string first;
    public string second;
    public int cutPos;
    public bool finished;
}
